import { Hero } from './hero';

export const HEROES: Hero[] = [
  { id: 1, name: 'List', power: 'Make your own unique lists for any food or drink places you want to save, remember, share, or show off!' },
  { id: 2, name: 'Tags', power: 'Categorize your lists with tags like "breakfast", "comfort", "Japanese", and more.' },
  { id: 3, name: 'Carousel', power: 'Flex some of your best food pics on your profile carousel. These pics will loop forever <3' },
  { id: 4, name: 'Customize', power: 'Edit your lists, make them cute, add tags, photos, details!' },
  { id: 5, name: 'Friends', power: 'Share your list or profile to your friends and view theirs too~' },
];


/*
Copyright Google LLC. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/